#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"
#include "hash.h"
#include "bitmap.h"
#include "debug.h"

//element
struct list_elem * e, * e1, * e2, *tmp;
//item
struct list_item * item;
//element
struct hash_elem * hash_item;

//array
struct list lists[10];
struct hash hashes[10];
struct bitmap * bms[10];

/////////List_Function/////////////
bool list_less (const struct list_elem *a, const struct list_elem *b, void *aux){
  struct list_item * A = list_entry(a, struct list_item, elem);
  struct list_item * B = list_entry(b, struct list_item, elem);
  return (A->data) < (B->data);
}
/////////List_Function/////////////

/////////Hash_Function/////////////
unsigned hash_func(const struct hash_elem *e, void *aux){
  return hash_int(e->data);
}
void hash_print(struct hash_elem *e, void *aux){
  printf("%d ",e->data);
}
void hash_square(struct hash_elem *e, void *aux){
  int S =e->data;
  S=S*S;
  e->data=S;
}
void hash_triple(struct hash_elem *e, void *aux){
  int S =e->data;
  S=S*S*S;
  e->data=S;
}
bool hash_less(const struct hash_elem *a, const struct hash_elem *b, void *aux){
  return (a->data) < (b->data);
}
/////////Hash_Function/////////////

char Com[50]={0,};
char Arg[6][50]={0,};
int i, idx, idx2;
bool B;

int main(){
  while(1)
  {
    //input
    fgets(Com,50,stdin);
    Com[strlen(Com)-1]='\0';
    char * com=strtok(Com," ");
    
    //dividing command
    memset(Arg, 0, sizeof(Arg)); 
    i=0;
    while(com != NULL)
    {
      strcpy(Arg[i],com);
      com = strtok(NULL, " ");
      i++;
    }
    //index
    idx = (int)Arg[1][strlen(Arg[1])-1]-'0';
    B=false;

////////////////////////////BASIC_COMMAND////////////////////////////////

    // create
    if(!strcmp(Arg[0],"create"))
    {
      idx = (int)Arg[2][strlen(Arg[2])-1]-'0';
      //list
      if(!strcmp(Arg[1],"list"))
        list_init(&lists[idx]);
      //hashtable
      else if(!strcmp(Arg[1],"hashtable"))
        hash_init(&hashes[idx],hash_func,hash_less,NULL);
      //bitmap
      else if(!strcmp(Arg[1],"bitmap"))
        bms[idx] = bitmap_create((size_t)atoi(Arg[3]));
    }

    // delete
    else if(!strcmp(Arg[0],"delete"))
    {
      //seperate digit from str
      idx2=strlen(Arg[1])-1;
      //what type
      char type[5];
      strncpy(type,Arg[1],idx2);
      type[idx2]='\0';
      //list
      if(!strcmp(type,"list"))
        while(!list_empty(&lists[idx]))
          list_pop_back(&lists[idx]);
      //hash
      else if(!strcmp(type,"hash"))
        hash_clear(&hashes[idx],NULL);     
      //bm
      else if(!strcmp(type,"bm")){
        bitmap_destroy(bms[idx]);     
        bms[idx]=NULL;   
      }
    }

    // dumpdata
    else if(!strcmp(Arg[0],"dumpdata"))
    {
      //seperate digit from str
      idx2=strlen(Arg[1])-1;
      //what type
      char type[5];
      strncpy(type,Arg[1],idx2);
      type[idx2]='\0';

      //list
      if(!strcmp(type,"list")){
        //empty case
        if(list_empty(&lists[idx])) continue;
        //else case
        for (e = list_begin (&lists[idx]); e != list_end (&lists[idx]); e = list_next (e)){
          item = list_entry(e, struct list_item, elem);
          printf("%d ",item->data);
        }
        printf("\n");
      }
      //hash
      else if(!strcmp(type,"hash")){
        //empty case
        if(hash_empty(&hashes[idx])) continue;
        //else case
        hash_apply(&hashes[idx],hash_print);
        printf("\n");       
      }
      //bm
      else if(!strcmp(type,"bm")){
        size_t count = bitmap_size(bms[idx]);
        for(size_t i=0;i< count;i++)
          printf("%d",bitmap_test(bms[idx],i));
        printf("\n");     
      }
    }

    // quit
    else if(!strcmp(Arg[0],"quit")) return 0;

////////////////////////////BASIC_COMMAND////////////////////////////////

////////////////////////////LIST_COMMAND/////////////////////////////////

    else if(!strcmp(Arg[0],"list_push_front")){
      struct list_item * new = (struct list_item *)malloc(sizeof(struct list_item));
      new->data=atoi(Arg[2]);
      list_push_front(&lists[idx],&new->elem);
    }

    else if(!strcmp(Arg[0],"list_push_back")){
      struct list_item * new = (struct list_item *)malloc(sizeof(struct list_item));
      new->data=atoi(Arg[2]);
      list_push_back(&lists[idx],&new->elem);
    }

    else if(!strcmp(Arg[0],"list_pop_front"))
      e = list_pop_front(&lists[idx]);

    else if(!strcmp(Arg[0],"list_pop_back"))
      e = list_pop_back(&lists[idx]);

    else if(!strcmp(Arg[0],"list_front")){
      e = list_front(&lists[idx]);
      item = list_entry(e, struct list_item, elem);
      printf("%d\n",item->data);
    }

    else if(!strcmp(Arg[0],"list_back")){
      e = list_back(&lists[idx]);
      item = list_entry(e, struct list_item, elem);
      printf("%d\n",item->data);
    }

    else if(!strcmp(Arg[0],"list_insert_ordered")){
      struct list_item * new = (struct list_item *)malloc(sizeof(struct list_item));
      new->data = atoi(Arg[2]);
      list_insert_ordered(&lists[idx],&new->elem,list_less,NULL);
    }

    else if(!strcmp(Arg[0],"list_insert")){
      struct list_item * new = (struct list_item *)malloc(sizeof(struct list_item));
      new->data = atoi(Arg[3]);
      e = list_idx(&lists[idx],atoi(Arg[2]));
      list_insert(e,&new->elem);
    }

    else if(!strcmp(Arg[0],"list_empty"))
      printf("%s\n", list_empty(&lists[idx]) ? "true\n" : "false\n");

    else if(!strcmp(Arg[0],"list_size"))
      printf("%zu\n", list_size(&lists[idx]));

    else if(!strcmp(Arg[0],"list_max")){
      e = list_max(&lists[idx],list_less,NULL);
      item = list_entry(e, struct list_item, elem);
      printf("%d\n",item->data);
    }
    else if(!strcmp(Arg[0],"list_min")){
      e = list_min(&lists[idx],list_less,NULL);
      item = list_entry(e, struct list_item, elem);
      printf("%d\n",item->data);
    }

    else if(!strcmp(Arg[0],"list_remove")){
      e = list_idx(&lists[idx], atoi(Arg[2]));
      list_remove(e);
    }

    else if(!strcmp(Arg[0],"list_reverse"))
      list_reverse(&lists[idx]);

    else if(!strcmp(Arg[0],"list_shuffle"))
      list_suffle(&lists[idx]);
    
    else if(!strcmp(Arg[0],"list_sort"))
      list_sort(&lists[idx],list_less,NULL);

    else if(!strcmp(Arg[0],"list_splice")){
      idx2 = (int)Arg[3][strlen(Arg[3])-1]-'0';
      e = list_idx(&lists[idx], atoi(Arg[2]));
      e1 = list_idx(&lists[idx2], atoi(Arg[4]));
      e2 = list_idx(&lists[idx2], atoi(Arg[5]));
      list_splice (e, e1, e2);
    }

    else if(!strcmp(Arg[0],"list_swap")){
      if(atoi(Arg[2]) < atoi(Arg[3])){
        e = list_idx(&lists[idx],atoi(Arg[2]));
        e1 = list_idx(&lists[idx],atoi(Arg[3]));
      }
      else{
        e1 = list_idx(&lists[idx],atoi(Arg[2]));
        e = list_idx(&lists[idx],atoi(Arg[3]));
      }
      list_swap(e,e1);
    }

    else if(!strcmp(Arg[0],"list_unique")){
      idx2 = (int)Arg[2][strlen(Arg[2])-1]-'0';
      if(Arg[2][0]==0) list_unique(&lists[idx],NULL,list_less,NULL);
      else list_unique(&lists[idx],&lists[idx2],list_less,NULL);
    }

////////////////////////////LIST_COMMAND/////////////////////////////////

////////////////////////////HASH_COMMAND/////////////////////////////////

    else if(!strcmp(Arg[0],"hash_insert")){
      struct hash_elem * new = (struct hash_elem*)malloc(sizeof(struct hash_elem));
      new->data=atoi(Arg[2]);
      hash_insert(&hashes[idx], new);
    }

    else if(!strcmp(Arg[0],"hash_apply")){
      if(!strcmp(Arg[2],"square")) hash_apply(&hashes[idx], hash_square);
      else if(!strcmp(Arg[2],"triple")) hash_apply(&hashes[idx], hash_triple);
    }

    else if(!strcmp(Arg[0],"hash_delete")){
      struct hash_elem * new = (struct hash_elem*)malloc(sizeof(struct hash_elem));
      new->data=atoi(Arg[2]);
      hash_delete(&hashes[idx], new);
    }

    else if(!strcmp(Arg[0],"hash_empty")){
      B = hash_empty(&hashes[idx]);
      printf("%s\n", B ? "true" : "false");
    }

    else if(!strcmp(Arg[0],"hash_size")){
      size_t S = hash_size (&hashes[idx]); 
      printf("%zu\n",S);
    }

    else if(!strcmp(Arg[0],"hash_clear"))
      hash_clear(&hashes[idx],NULL);

    else if(!strcmp(Arg[0],"hash_find")){
      struct hash_elem * new = (struct hash_elem*)malloc(sizeof(struct hash_elem));
      new->data=atoi(Arg[2]);
      new = hash_find(&hashes[idx], new);
      if(new != NULL) printf("%d\n",new->data);
    }

    else if(!strcmp(Arg[0],"hash_replace")){
      struct hash_elem * new = (struct hash_elem*)malloc(sizeof(struct hash_elem));
      new->data=atoi(Arg[2]);
      hash_replace(&hashes[idx], new);
    }

////////////////////////////HASH_COMMAND/////////////////////////////////

////////////////////////////BITMAP_COMMAND///////////////////////////////

    else if(!strcmp(Arg[0],"bitmap_mark"))
      bitmap_mark(bms[idx], (size_t)atoi(Arg[2]));

    else if(!strcmp(Arg[0],"bitmap_all")){
      B = bitmap_all(bms[idx],(size_t)atoi(Arg[2]), (size_t)atoi(Arg[3]));
      printf("%s\n", B ? "true" : "false");
    }

    else if(!strcmp(Arg[0],"bitmap_any")){
      B = bitmap_any(bms[idx],(size_t)atoi(Arg[2]), (size_t)atoi(Arg[3]));
      printf("%s\n", B ? "true" : "false");
    }

    else if(!strcmp(Arg[0],"bitmap_count")){
      if(!strcmp(Arg[4],"true")) B = true;
      size_t S = bitmap_count(bms[idx],(size_t)atoi(Arg[2]), (size_t)atoi(Arg[3]),B);
      printf("%zu\n",S);
    }

    else if(!strcmp(Arg[0],"bitmap_contains")){
      if(!strcmp(Arg[4],"true")) B = true;
      B = bitmap_contains(bms[idx],(size_t)atoi(Arg[2]), (size_t)atoi(Arg[3]),B);
      printf("%s\n", B ? "true" : "false");
    }

    else if(!strcmp(Arg[0],"bitmap_dump"))
      bitmap_dump(bms[idx]);

    else if(!strcmp(Arg[0],"bitmap_flip"))
      bitmap_flip(bms[idx],(size_t)atoi(Arg[2]));

    else if(!strcmp(Arg[0],"bitmap_none")){
      B = bitmap_none(bms[idx],(size_t)atoi(Arg[2]), (size_t)atoi(Arg[3]));
      printf("%s\n", B ? "true" : "false");
    }

    else if(!strcmp(Arg[0],"bitmap_reset"))
      bitmap_reset(bms[idx],(size_t)atoi(Arg[2]));

    else if(!strcmp(Arg[0],"bitmap_scan_and_flip")){
      if(!strcmp(Arg[4],"true")) B = true;
      size_t S = bitmap_scan_and_flip(bms[idx],(size_t)atoi(Arg[2]), (size_t)atoi(Arg[3]),B);
      printf("%zu\n",S);
    }

    else if(!strcmp(Arg[0],"bitmap_scan")){
      if(!strcmp(Arg[4],"true")) B = true;
      size_t S = bitmap_scan(bms[idx],(size_t)atoi(Arg[2]), (size_t)atoi(Arg[3]),B);
      printf("%zu\n",S);
    }

    else if(!strcmp(Arg[0],"bitmap_set_all")){
      if(!strcmp(Arg[2],"true")) B = true;
      bitmap_set_all(bms[idx],B);
    }

    else if(!strcmp(Arg[0],"bitmap_set_multiple")){
      if(!strcmp(Arg[4],"true")) B = true;
      bitmap_set_multiple(bms[idx],(size_t)atoi(Arg[2]), (size_t)atoi(Arg[3]),B);
    }

    else if(!strcmp(Arg[0],"bitmap_set")){
      if(!strcmp(Arg[3],"true")) B = true;
      bitmap_set(bms[idx],(size_t)atoi(Arg[2]),B);
    }

    else if(!strcmp(Arg[0],"bitmap_size")){
      size_t S = bitmap_size(bms[idx]);
      printf("%zu\n",S);
    }

    else if(!strcmp(Arg[0],"bitmap_test")){
      B = bitmap_test(bms[idx],(size_t)atoi(Arg[2]));
      printf("%s\n", B ? "true" : "false");
    }

    else if(!strcmp(Arg[0],"bitmap_expand"))
      bitmap_expand(bms[idx], (size_t)atoi(Arg[2]));

////////////////////////////BITMAP_COMMAND///////////////////////////////
  }
}