#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "mm.h"
#include "memlib.h"

 /*********************************************************
  * NOTE TO STUDENTS: Before you do anything else, please
  * provide your information in the following struct.
  ********************************************************/
team_t team = {
	/* Your student ID */
	"20212022",
	/* Your full name*/
	"Yejun Lee",
	/* Your email address */
	"yejunaja@sogang.ac.kr",
};

#define WSIZE       	  4      
#define DSIZE       	  8      
#define CHUNKSIZE  		  (1<<12)
#define BUFFER	          256
#define TOTAL_LIST	      32

#define NEXT_BLKP(bp)     ((char *)(bp) + GET_SIZE(((char *)(bp) - WSIZE)))
#define PREV_BLKP(bp)     ((char *)(bp) - GET_SIZE(((char *)(bp) - DSIZE)))

#define SET_PTR(p, ptr)	  (*(unsigned int *)(p) = (unsigned int)(ptr))
#define PUT_TAG(p, val)	  (*(unsigned int *)(p) = (val) | GET_TAG(p))
#define PUT(p, val)		  (*(unsigned int *)(p) = (val)) 
#define GET(p)		      (*(unsigned int *)(p))      

#define FTRP(bp)          ((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)
#define HDRP(bp)          ((char *)(bp) - WSIZE)                       

#define ALIGN(size)       (((size) + (DSIZE-1)) & ~0x7)
#define SIZE_T_SIZE       (ALIGN(sizeof(size_t)))

#define SUCC(bp)	      (*(char **)(bp + WSIZE))
#define PRED(bp)	      (*(char **)(bp))

#define SUCC_PTR(bp)	  ((char *)(bp) + WSIZE)
#define PRED_PTR(bp)	  ((char *)(bp))

#define MAX(x, y)         ((x) > (y) ? (x) : (y))
#define MIN(x, y)         ((x) < (y) ? (x) : (y))

#define PACK(size, alloc) ((size) | (alloc))

#define REMOVE_TAG(p)	  (GET(p) &= ~0x2)
#define GET_SIZE(p)		  (GET(p) & ~0x7)             
#define GET_ALLOC(p)	  (GET(p) & 0x1)               
#define GET_TAG(p)		  (GET(p) & 0x2)
#define SET_TAG(p)		  (GET(p) | 0x2) 

static void* find_fit(void* list, size_t asize);
static void add_seglist(char* bp, size_t size);
static void* place(void* bp, size_t asize);
static void* extend_heap(size_t words);
static void remove_seglist(char* bp);
static void* coalesce(void* bp);

static void* seg_lists[TOTAL_LIST];

int mm_init(void)
{
	void* start;

	if ((start = mem_sbrk(4 * WSIZE)) == (void*)-1) return -1; 

	PUT(start, 0);
	PUT(start + WSIZE, PACK(DSIZE, 1));
	PUT(start + (2 * WSIZE), PACK(DSIZE, 1));
	PUT(start + (3 * WSIZE), PACK(0, 1));

	for (int i = 0; i < TOTAL_LIST; i++) seg_lists[i] = NULL;

	if (extend_heap(CHUNKSIZE) == NULL) return -1; 

	return 0; 
}

static void* find_fit(void* list, size_t asize) {
    void* bp = list;
    
    while (bp != NULL && (asize > GET_SIZE(HDRP(bp)) || GET_TAG(HDRP(bp)))) bp = SUCC(bp);
    
    return bp;
}

void* mm_malloc(size_t size)
{
    if (size == 0) return NULL; 

    size_t asize = MAX(ALIGN(size + SIZE_T_SIZE), 2*DSIZE);
	void* bp = NULL;

	for (int i = 0; i < TOTAL_LIST; i++) {
		if (seg_lists[i] != NULL && ((asize <= (1 << (i + 4))) || i == (TOTAL_LIST - 1))) {
			bp = find_fit(seg_lists[i], asize);
			if (bp != NULL) return place(bp, asize);
		}
	}

	size_t extendsize = MAX(asize, CHUNKSIZE);                 
	if ((bp = extend_heap(extendsize)) == NULL) return NULL;                                 

	return place(bp, asize);                                
}

void mm_free(void* ptr)
{
	if (ptr == 0) return;

	size_t size = GET_SIZE(HDRP(ptr));

	PUT_TAG(HDRP(ptr), PACK(size, 0));
	PUT_TAG(FTRP(ptr), PACK(size, 0));
	REMOVE_TAG(HDRP(NEXT_BLKP(ptr)));

	add_seglist(ptr, size);
	coalesce(ptr);
}

void* mm_realloc(void* ptr, size_t size)
{
	if (size == 0) {
        mm_free(ptr);
        return NULL;
    }

    if (ptr == NULL) return mm_malloc(size);

    size_t new_size = size + DSIZE; 
    size_t current_size = GET_SIZE(HDRP(ptr));

    if (new_size <= 2 * DSIZE) new_size = 2 * DSIZE;
    else new_size = DSIZE * ((new_size + (DSIZE - 1)) / DSIZE);
    
    new_size += BUFFER;

    int block_size = current_size - new_size;

    if (block_size < 0) { 
        if (GET_ALLOC(HDRP(NEXT_BLKP(ptr))) && GET_SIZE(HDRP(NEXT_BLKP(ptr)))) {
            void* new_ptr = mm_malloc(new_size - DSIZE);
            if (new_ptr == NULL) return NULL; 
            memcpy(new_ptr, ptr, MIN(size, new_size));
            mm_free(ptr);
            return new_ptr;
        } else {
            int remainder = current_size + GET_SIZE(HDRP(NEXT_BLKP(ptr))) - new_size;
            if (remainder < 0) {
                int extend_size = MAX(CHUNKSIZE, -remainder);
                if (extend_heap(extend_size) == NULL) return NULL; 
                remainder += extend_size;
            }
            remove_seglist(NEXT_BLKP(ptr));
            PUT(HDRP(ptr), PACK(new_size + remainder, 1));
            PUT(FTRP(ptr), PACK(new_size + remainder, 1));
            block_size = GET_SIZE(HDRP(ptr)) - new_size;
        }
    }

    if (block_size < 2 * BUFFER)  (void)SET_TAG(HDRP(NEXT_BLKP(ptr)));

    return ptr;
}

static void add_seglist(char* bp, size_t size)
{
    void* head = NULL;
    void* before = NULL;
    int i = 0;

    for (i = 0; i < TOTAL_LIST; i++) 
        if (size <= (1 << (i + 4)) || i == (TOTAL_LIST - 1)) break;
    
    head = seg_lists[i];
    while (head != NULL && size > GET_SIZE(HDRP(head))) {
        before = head;
        head = SUCC(head);
    }

    // Connect bp into the segregated list
    SET_PTR(PRED_PTR(bp), before);
    if (before != NULL) {
        SET_PTR(SUCC_PTR(bp), head);
        SET_PTR(SUCC_PTR(before), bp);
    } else {
        SET_PTR(SUCC_PTR(bp), head);
        seg_lists[i] = bp; // Update seg_lists[i] if before is NULL
    }
    if (head != NULL) {
        SET_PTR(PRED_PTR(head), bp);
    }

    SET_PTR(PRED_PTR(bp), before);
}

static void remove_seglist(char* bp)
{
	size_t size = GET_SIZE(HDRP(bp));
    int i;

    for (i = 0; i < TOTAL_LIST; i++) 
        if (size <= (1 << (i + 4)) || i == (TOTAL_LIST - 1)) break;
    
    if (PRED(bp)) SET_PTR(SUCC_PTR(PRED(bp)), SUCC(bp));
    else seg_lists[i] = SUCC(bp);
    
    if (SUCC(bp)) SET_PTR(PRED_PTR(SUCC(bp)), PRED(bp));

    SET_PTR(PRED_PTR(bp), NULL);
    SET_PTR(SUCC_PTR(bp), NULL);
}

static void* coalesce(void* bp)
{
	size_t prev_alloc = GET_ALLOC(HDRP(PREV_BLKP(bp))) || GET_TAG(HDRP(PREV_BLKP(bp)));
    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
    size_t size = GET_SIZE(HDRP(bp));

    if (prev_alloc && next_alloc) {
        return bp;
    } else if (prev_alloc && !next_alloc) {
        size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
        remove_seglist(bp);
        remove_seglist(NEXT_BLKP(bp));
        PUT_TAG(HDRP(bp), PACK(size, 0));
        PUT_TAG(FTRP(bp), PACK(size, 0));
        add_seglist(bp, size);
    } else if (!prev_alloc && next_alloc) {
        size += GET_SIZE(HDRP(PREV_BLKP(bp)));
        remove_seglist(PREV_BLKP(bp));
        remove_seglist(bp);
        PUT_TAG(FTRP(bp), PACK(size, 0));
        PUT_TAG(HDRP(PREV_BLKP(bp)), PACK(size, 0));
        bp = PREV_BLKP(bp);
        add_seglist(bp, size);
    } else {
        size += GET_SIZE(HDRP(PREV_BLKP(bp))) + GET_SIZE(HDRP(NEXT_BLKP(bp)));
        remove_seglist(PREV_BLKP(bp));
        remove_seglist(bp);
        remove_seglist(NEXT_BLKP(bp));
        PUT_TAG(HDRP(PREV_BLKP(bp)), PACK(size, 0));
        PUT_TAG(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
        bp = PREV_BLKP(bp);
        add_seglist(bp, size);
    }

    return bp;
}

static void* extend_heap(size_t words)
{
	void* bp;
	size_t asize = (size_t)(words + DSIZE - 1) & ~0x7;
    
	if ((bp = mem_sbrk(asize)) == (void*)-1) return NULL;

	PUT(HDRP(bp), PACK(asize, 0));
	PUT(FTRP(bp), PACK(asize, 0));
	PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1));
	add_seglist(bp, asize);

	return coalesce(bp);
}

static void* place(void* bp, size_t asize)
{
	size_t csize = GET_SIZE(HDRP(bp));
    remove_seglist(bp);

    if ((csize - asize) >= (2 * DSIZE)) {
        if (asize < 100) {
            PUT_TAG(HDRP(bp), PACK(asize, 1));
            PUT_TAG(FTRP(bp), PACK(asize, 1));
            PUT(HDRP(NEXT_BLKP(bp)), PACK(csize - asize, 0));
            PUT(FTRP(NEXT_BLKP(bp)), PACK(csize - asize, 0));
            add_seglist(NEXT_BLKP(bp), csize - asize);
            return bp;
        } else {
            PUT_TAG(HDRP(bp), PACK(csize - asize, 0));
            PUT_TAG(FTRP(bp), PACK(csize - asize, 0));
            PUT(HDRP(NEXT_BLKP(bp)), PACK(asize, 1));
            PUT(FTRP(NEXT_BLKP(bp)), PACK(asize, 1));
            add_seglist(bp, csize - asize);
            return NEXT_BLKP(bp);
        }
    } else {
        PUT_TAG(HDRP(bp), PACK(csize, 1));
        PUT_TAG(FTRP(bp), PACK(csize, 1));
        return bp;
    }
}